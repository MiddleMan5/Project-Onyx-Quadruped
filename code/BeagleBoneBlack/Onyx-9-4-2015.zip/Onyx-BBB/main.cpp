/* 
 * File:   main.cpp
 * Author: Quinn
 *
 * Created on August 2, 2015, 12:23 PM
 */

#include "libraries/Onyx/Onyx.h"
Onyx MK1;

main() {
    cout << "Onyx Initializing...";
    endl(cout);
    MK1.setMode(STARTUP);
    cout << "Onyx Initialized. Program Start.";
    endl(cout);
    do MK1.setMode(STANDBY); while (1 == 1);
}