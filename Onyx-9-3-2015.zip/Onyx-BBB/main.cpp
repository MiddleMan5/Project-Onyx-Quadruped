/* 
 * File:   main.cpp
 * Author: Quinn
 *
 * Created on August 2, 2015, 12:23 PM
 */

#include "libraries/Onyx/Onyx.h"
using namespace std;
Onyx MK1;
void setup(){MK1.setMode(STARTUP);} 
void loop(){MK1.setMode(STANDBY);}
